import React from 'react'

const Hero = () => {
  return (
    <div>Hero</div>
  )
}

export default Hero