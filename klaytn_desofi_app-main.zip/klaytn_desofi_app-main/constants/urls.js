const urls = {
  WEB_URL: process.env.NEXT_PUBLIC_WEB_URL,
};

export default urls;
