import "@/theme/globals.css";

const RootLayout = (props) => {
  const { children } = props;
  return children;
};

export default RootLayout;
